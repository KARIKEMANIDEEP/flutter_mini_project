class AppRoute{
  static const splash = '/';
  static const login = '/login';
  static const products = 'products';
}