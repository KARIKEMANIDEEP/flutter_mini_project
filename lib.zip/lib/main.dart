import 'package:flutter/material.dart';
import 'package:mini_project/app.dart';
void main(){
  runApp(const MyApp());
}